﻿using System.Windows;
using System.Windows.Controls.Primitives;
using QuorumAPI;

namespace TemplateUi
{
    public partial class SettingsWindow : Window
    {
        public SettingsWindow()
        {
            InitializeComponent();

            this.Loaded += (s, e) =>
            {
                if (Owner != null)
                {
                    this.Left = Owner.Left + Owner.Width - 10;
                    this.Top = Owner.Top;
                    if (BtnTopMost != null) BtnTopMost.IsChecked = Owner.Topmost;
                }
            };
        }

        private void TopMost_Click(object sender, RoutedEventArgs e)
        {
            if (Owner != null && sender is ToggleButton toggle)
            {
                Owner.Topmost = toggle.IsChecked == true;
            }
        }

        private void AutoAttach_Click(object sender, RoutedEventArgs e)
        {
            if (sender is ToggleButton toggle)
            {
                // Tutorial.txt: SetAutoInject(bool)
                QuorumModule.SetAutoInject(toggle.IsChecked == true);
            }
        }

        private void AutoExec_Click(object sender, RoutedEventArgs e)
        {
            // _autoExec not mentioned in Tutorial.txt, leaving empty.
        }

        private void KillRoblox_Click(object sender, RoutedEventArgs e)
        {
            if (Owner is MainWindow main)
            {
                var selectedPids = main.GetSelectedPids();
                if (selectedPids != null && selectedPids.Count > 0)
                {
                    foreach (int pid in selectedPids)
                    {
                        try { System.Diagnostics.Process.GetProcessById(pid).Kill(); } catch { }
                    }
                    MessageBox.Show($"Killed {selectedPids.Count} selected sessions.");
                    return;
                }
            }

            // Tutorial.txt: KillRoblox()
            QuorumModule.KillRoblox();
        }
    }
}