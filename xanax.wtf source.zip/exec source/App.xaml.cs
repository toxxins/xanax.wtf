using System.Windows;

namespace TemplateUi;

public partial class App : Application
{
}
