﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using System.Xml;
using ICSharpCode.AvalonEdit;
using ICSharpCode.AvalonEdit.Highlighting;
using ICSharpCode.AvalonEdit.Highlighting.Xshd;
using Microsoft.Win32;
using QuorumAPI;

namespace TemplateUi;

public class RobloxSession
{
    public string ProcessName { get; set; } = "RobloxPlayerBeta";
    public int Pid { get; set; }
    public bool IsSelected { get; set; }
}

public class ScriptResult
{
    public string Title { get; set; } = "";
    public string Game { get; set; } = "";
    public string ScriptContent { get; set; } = "";
    public string ImageUrl { get; set; } = "";
}

public partial class MainWindow : Window
{
    private readonly Random _random = new Random();
    private readonly string[] _randomPhrases = { "xanax.wtf", "welcome to xanax", "bruh meme" };
    private SettingsWindow? _settingsWindow;
    private static readonly HttpClient _httpClient = new HttpClient();

    private DispatcherTimer _statusTimer;

    // Paths
    private readonly string _basePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "xanax");
    private readonly string _scriptsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "xanax", "Scripts");

    public ObservableCollection<RobloxSession> RobloxProcesses { get; set; } = new ObservableCollection<RobloxSession>();

    public MainWindow()
    {
        InitializeComponent();

        if (!Directory.Exists(_basePath)) Directory.CreateDirectory(_basePath);
        if (!Directory.Exists(_scriptsPath)) Directory.CreateDirectory(_scriptsPath);

        if (!System.ComponentModel.DesignerProperties.GetIsInDesignMode(this))
        {
            try
            {
                // NOTE: 'SetWorkspacePath' is not in Tutorial.txt, so it is removed to prevent errors.

                _statusTimer = new DispatcherTimer();
                _statusTimer.Interval = TimeSpan.FromSeconds(3);
                _statusTimer.Tick += StatusTimer_Tick;
                _statusTimer.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error initializing: {ex.Message}\nEnsure QuorumAPI.dll is in the folder and build is x64.");
            }
        }

        if (ProcessList != null)
            ProcessList.ItemsSource = RobloxProcesses;

        this.LocationChanged += (s, e) => UpdateSettingsPosition();
        AddTab_Click(null, null);
        SwitchView("Editor");
        _ = PerformSearch("");
    }

    public List<int> GetSelectedPids()
    {
        return RobloxProcesses.Where(x => x.IsSelected).Select(x => x.Pid).ToList();
    }

    private void RefreshProcesses_Click(object sender, RoutedEventArgs e)
    {
        RobloxProcesses.Clear();
        var processes = Process.GetProcesses().Where(p => p.ProcessName.Contains("RobloxPlayerBeta"));
        foreach (var p in processes)
        {
            RobloxProcesses.Add(new RobloxSession { ProcessName = p.ProcessName, Pid = p.Id, IsSelected = false });
        }
    }

    private void SelectAll_Click(object sender, RoutedEventArgs e)
    {
        foreach (var p in RobloxProcesses) p.IsSelected = true;
        ProcessList.Items.Refresh();
    }

    private void DeselectAll_Click(object sender, RoutedEventArgs e)
    {
        foreach (var p in RobloxProcesses) p.IsSelected = false;
        ProcessList.Items.Refresh();
    }

    private void InjectSelected_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            // Tutorial.txt: AttachAPI(bool)
            QuorumModule.AttachAPI(true);
            MessageBox.Show("Injection initiated.");
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Failed to attach: {ex.Message}");
        }
    }

    private void ExecuteSelected_Click(object sender, RoutedEventArgs e)
    {
        var editor = GetCurrentEditor();
        if (editor == null) return;

        try
        {
            // Tutorial.txt: ExecuteScript(string)
            QuorumModule.ExecuteScript(editor.Text);
        }
        catch { }
    }

    private void StatusTimer_Tick(object sender, EventArgs e)
    {
        try
        {
            // Tutorial.txt: IsAttached() returns int (1 = attached)
            if (QuorumModule.IsAttached() == 1)
                StatusIndicator.Fill = Brushes.Green;
            else
                StatusIndicator.Fill = Brushes.Red;
        }
        catch { StatusIndicator.Fill = Brushes.Gray; }
    }

    private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount == 2) { ToggleMaximize(); return; }
        DragMove();
    }
    private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    // private void Maximize_Click(object sender, RoutedEventArgs e) => ToggleMaximize();
    private void Close_Click(object sender, RoutedEventArgs e) { _settingsWindow?.Close(); Close(); }
    private void ToggleMaximize()
    {
        WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        UpdateSettingsPosition();
    }
    private void UpdateSettingsPosition()
    {
        if (_settingsWindow != null && _settingsWindow.IsVisible)
        {
            _settingsWindow.Left = this.Left + this.Width - 10;
            _settingsWindow.Top = this.Top;
        }
    }

    protected override void OnClosed(EventArgs e)
    {
        base.OnClosed(e);
        if (_statusTimer != null) _statusTimer.Stop();
    }

    private int _scriptCounter = 1;
    private void AddTab_Click(object sender, RoutedEventArgs e) => CreateTab($"Script {_scriptCounter++}", "");

    private void CreateTab(string title, string content)
    {
        var editor = new TextEditor
        {
            FontFamily = new FontFamily("Consolas"),
            FontSize = 13,
            Foreground = (Brush)FindResource("TextPrimaryBrush"),
            ShowLineNumbers = true,
            Background = Brushes.Transparent,
            Text = content,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto
        };
        ConfigureLuaEditor(editor);

        var headerPanel = new StackPanel { Orientation = Orientation.Horizontal, Background = Brushes.Transparent };
        var nameBlock = new TextBlock { Text = title, Foreground = (Brush)FindResource("TextMutedBrush"), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 8, 0), MaxWidth = 120, TextTrimming = TextTrimming.CharacterEllipsis };
        var nameBox = new TextBox { Text = title, Background = new SolidColorBrush(Color.FromRgb(30, 30, 30)), BorderThickness = new Thickness(1), BorderBrush = (Brush)FindResource("PanelBorderBrush"), Foreground = (Brush)FindResource("TextPrimaryBrush"), MinWidth = 60, Margin = new Thickness(0, 0, 5, 0), Visibility = Visibility.Collapsed };

        var contextMenu = new ContextMenu();
        var renameItem = new MenuItem { Header = "Rename" };
        renameItem.Click += (s, e) => { nameBox.Text = nameBlock.Text; nameBlock.Visibility = Visibility.Collapsed; nameBox.Visibility = Visibility.Visible; nameBox.Focus(); nameBox.SelectAll(); };
        contextMenu.Items.Add(renameItem);
        headerPanel.ContextMenu = contextMenu;

        Action saveRename = () => { nameBlock.Text = nameBox.Text; nameBox.Visibility = Visibility.Collapsed; nameBlock.Visibility = Visibility.Visible; };
        nameBox.LostFocus += (s, e) => saveRename();
        nameBox.KeyDown += (s, e) => { if (e.Key == Key.Enter) { saveRename(); Keyboard.ClearFocus(); } };

        var closeBtn = new Button { Content = "x", Width = 16, Height = 16, FontSize = 12, Background = Brushes.Transparent, Foreground = (Brush)FindResource("TextMutedBrush"), BorderThickness = new Thickness(0), Cursor = Cursors.Hand, Padding = new Thickness(0, -2, 0, 0), VerticalAlignment = VerticalAlignment.Center };
        closeBtn.Click += (s, e) => {
            var tab = (TabItem)((FrameworkElement)s).TemplatedParent;
            if (tab == null) { DependencyObject curr = (DependencyObject)s; while (curr != null && !(curr is TabItem)) curr = VisualTreeHelper.GetParent(curr); tab = (TabItem)curr; }
            if (tab != null) { ScriptTabs.Items.Remove(tab); if (ScriptTabs.Items.Count == 0) CreateTab($"Script {_scriptCounter++}", ""); }
        };

        headerPanel.Children.Add(nameBlock); headerPanel.Children.Add(nameBox); headerPanel.Children.Add(closeBtn);
        var tabItem = new TabItem { Header = headerPanel, Content = editor, Style = (Style)FindResource(typeof(TabItem)) };
        ScriptTabs.Items.Add(tabItem); ScriptTabs.SelectedItem = tabItem;
    }

    private TextEditor? GetCurrentEditor() { if (ScriptTabs.SelectedItem is TabItem tab && tab.Content is TextEditor editor) return editor; return null; }

    private void ScriptTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
    }

    private void Clear_Click(object sender, RoutedEventArgs e) { var editor = GetCurrentEditor(); if (editor != null) editor.Text = ""; }

    private void SaveFile_Click(object sender, RoutedEventArgs e)
    {
        var editor = GetCurrentEditor(); if (editor == null) return;
        var dialog = new SaveFileDialog { Filter = "Lua Scripts (*.lua)|*.lua|Text Files (*.txt)|*.txt", InitialDirectory = _scriptsPath, FileName = "script.lua" };

        if (dialog.ShowDialog() == true) { File.WriteAllText(dialog.FileName, editor.Text); if (ScriptTabs.SelectedItem is TabItem tab && tab.Header is StackPanel sp) { foreach (var child in sp.Children) { if (child is TextBlock tb) { tb.Text = Path.GetFileName(dialog.FileName); break; } } } }
    }

    private void OpenFile_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog { Filter = "Lua Scripts (*.lua)|*.lua|Text Files (*.txt)|*.txt", InitialDirectory = _scriptsPath };

        if (dialog.ShowDialog() == true) { string content = File.ReadAllText(dialog.FileName); CreateTab(Path.GetFileName(dialog.FileName), content); }
    }

    private void Execute_Click(object sender, RoutedEventArgs e)
    {
        var editor = GetCurrentEditor();
        if (editor != null)
        {
            QuorumModule.ExecuteScript(editor.Text ?? string.Empty);
        }
    }

    private void Attach_Click(object sender, RoutedEventArgs e)
    {
        StatusIndicator.Fill = Brushes.Yellow;
        try
        {
            // NOTE: 'SetAttachNotify' is not in Tutorial.txt, so it is removed.

            // Tutorial.txt: AttachAPIWithState()
            int result = QuorumModule.AttachAPIWithState();

            if (result == 1)
            {
                StatusIndicator.Fill = Brushes.Green;
                MessageBox.Show($"Successfully Attached!");
            }
            else
            {
                StatusIndicator.Fill = Brushes.Red;
                MessageBox.Show("Attach failed. The API reported failure.\nTry running as Admin.");
            }
        }
        catch (Exception ex)
        {
            StatusIndicator.Fill = Brushes.Orange;
            MessageBox.Show($"Attach Error: {ex.Message}\n\nEnsure your Antivirus is disabled and you are on x64 build.");
        }
    }

    private void SwitchView(string viewName)
    {
        HomeView.Visibility = Visibility.Collapsed; EditorView.Visibility = Visibility.Collapsed; ScriptHubView.Visibility = Visibility.Collapsed; MultiInstanceView.Visibility = Visibility.Collapsed;
        UIElement target = null;
        switch (viewName)
        {
            case "Home": target = HomeView; break;
            case "Editor": target = EditorView; break;
            case "ScriptHub": target = ScriptHubView; break;
            case "MultiInstance": target = MultiInstanceView; break;
        }
        if (target != null) { target.Visibility = Visibility.Visible; if (Resources["ViewFadeIn"] is Storyboard sb) sb.Begin((FrameworkElement)target); }
    }
    private void Home_Click(object sender, RoutedEventArgs e) => SwitchView("Home");
    private void Editor_Click(object sender, RoutedEventArgs e) => SwitchView("Editor");
    private void ScriptHub_Click(object sender, RoutedEventArgs e) => SwitchView("ScriptHub");
    private void MultiInstance_Click(object sender, RoutedEventArgs e) => SwitchView("MultiInstance");

    private void SettingsToggle_Click(object sender, RoutedEventArgs e)
    {
        if (SettingsToggle.IsChecked == true)
        {
            if (_settingsWindow == null) { _settingsWindow = new SettingsWindow(); _settingsWindow.Owner = this; }
            _settingsWindow.Left = this.Left + this.Width - 10; _settingsWindow.Top = this.Top; _settingsWindow.Show();
        }
        else { _settingsWindow?.Hide(); }
    }

    private async void SearchScripts_Click(object sender, RoutedEventArgs e) => await PerformSearch(ScriptSearchBox.Text);
    private async void ScriptSearchBox_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) await PerformSearch(ScriptSearchBox.Text); }

    private async Task PerformSearch(string query = "")
    {
        try
        {
            string url;
            if (string.IsNullOrWhiteSpace(query))
            {
                url = "https://scriptblox.com/api/script/fetch?page=1";
            }
            else
            {
                url = $"https://scriptblox.com/api/script/search?q={Uri.EscapeDataString(query)}&mode=free&page=1";
            }

            string json = await _httpClient.GetStringAsync(url);
            var scripts = new List<ScriptResult>();

            string pattern = "\"title\":\"(.*?)\".*?\"game\":{.*?\"name\":\"(.*?)\".*?}.*?\"image\":\"(.*?)\".*?\"script\":\"((?:[^\"\\\\]|\\\\.)*)\"";

            foreach (Match m in Regex.Matches(json, pattern))
            {
                string rawImg = m.Groups[3].Value;
                if (rawImg.StartsWith("/"))
                {
                    rawImg = "https://scriptblox.com" + rawImg;
                }

                scripts.Add(new ScriptResult
                {
                    Title = m.Groups[1].Value,
                    Game = m.Groups[2].Value,
                    ImageUrl = rawImg,
                    ScriptContent = Regex.Unescape(m.Groups[4].Value)
                });
            }
            ScriptList.ItemsSource = scripts;
        }
        catch { }
    }

    private void LoadScript_Click(object sender, RoutedEventArgs e) { if (sender is Button btn && btn.Tag is string script) { CreateTab("ScriptBlox Script", script); SwitchView("Editor"); } }

    private void Discord_Click(object sender, RoutedEventArgs e) => OpenUrl("https://discord.gg/xanax");
    private void Website_Click(object sender, RoutedEventArgs e) => OpenUrl("https://xanax.wtf");
    private void OpenUrl(string url) => Process.Start(new ProcessStartInfo { FileName = url, UseShellExecute = true });

    private void ConfigureLuaEditor(TextEditor editor)
    {
        using var stringReader = new StringReader(LuaHighlightingDefinition);
        using var xmlReader = XmlReader.Create(stringReader);
        var definition = HighlightingLoader.Load(xmlReader, HighlightingManager.Instance);
        editor.SyntaxHighlighting = definition;
    }

    private const string LuaHighlightingDefinition = @"
<SyntaxDefinition name=""Lua"" xmlns=""http://icsharpcode.net/sharpdevelop/syntaxdefinition/2008"">
  <Color name=""LuaComment"" foreground=""#666666"" />
  <Color name=""LuaKeyword"" foreground=""#FFFFFF"" fontWeight=""bold"" />
  <Color name=""LuaString"" foreground=""#CCCCCC"" />
  <Color name=""LuaNumber"" foreground=""#999999"" />
  <RuleSet>
    <Span color=""LuaComment""><Begin>--</Begin><End>\n</End></Span>
    <Rule color=""LuaString"">(""(\\.|[^""\\])*""|'(\\.|[^'\\])*')</Rule>
    <Keywords color=""LuaKeyword"">
      <Word>and</Word><Word>break</Word><Word>do</Word><Word>else</Word><Word>elseif</Word>
      <Word>end</Word><Word>false</Word><Word>for</Word><Word>function</Word><Word>if</Word>
      <Word>in</Word><Word>local</Word><Word>nil</Word><Word>not</Word><Word>or</Word>
      <Word>repeat</Word><Word>return</Word><Word>then</Word><Word>true</Word><Word>until</Word><Word>while</Word>
    </Keywords>
    <Rule color=""LuaNumber"">\b\d+(\.\d+)?\b</Rule>
  </RuleSet>
</SyntaxDefinition>";
}